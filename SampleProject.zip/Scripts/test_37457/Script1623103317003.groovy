import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.openqa.selenium.remote.RemoteWebDriver as RemoteWebDriver
import org.openqa.selenium.support.events.EventFiringWebDriver as EventFiringWebDriver
import com.applitools.eyes.BatchInfo as BatchInfo
import com.applitools.eyes.MatchLevel as MatchLevel
import com.applitools.eyes.selenium.Eyes as Eyes
import com.applitools.eyes.selenium.StitchMode as StitchMode
import com.applitools.eyes.selenium.fluent.Target as Target
import com.applitools.eyes.selenium.Configuration as Configuration
import com.applitools.eyes.EyesRunner as EyesRunner
import com.applitools.eyes.selenium.ClassicRunner as ClassicRunner
import com.applitools.eyes.visualgrid.services.RunnerOptions as RunnerOptions
import com.applitools.eyes.visualgrid.services.VisualGridRunner as VisualGridRunner
import com.applitools.eyes.selenium.BrowserType as BrowserType
import com.applitools.eyes.visualgrid.model.IosDeviceInfo as IosDeviceInfo
import com.applitools.eyes.visualgrid.model.IosDeviceName as IosDeviceName
import com.applitools.eyes.visualgrid.model.ChromeEmulationInfo as ChromeEmulationInfo
import com.applitools.eyes.visualgrid.model.DeviceName as DeviceName
import com.applitools.eyes.visualgrid.model.ScreenOrientation as ScreenOrientation
import com.kms.katalon.core.webui.driver.DriverFactory as DF
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

//import internal.GlobalVariable as GlobalVariable
//WebUI.openBrowser(GlobalVariable.Aviation_URL)
WebUI.openBrowser('https://demo.applitools.com')

WebUI.maximizeWindow()

//WebUI.comment('URL = ' + GlobalVariable.Aviation_URL)
//WebUI.waitForPageLoad(30)
//WebUI.takeScreenshot()
//WebUI.click(findTestObject('Land/btn_Accept_all_cookies'))
EventFiringWebDriver Driver = DF.getWebDriver()

RemoteWebDriver innerDriver = Driver.getWrappedDriver()

//Eyes eyes = CustomKeywords.'appliTools.createEyes'()
EyesRunner runner = new VisualGridRunner(new RunnerOptions().testConcurrency(5))

Eyes eyes = new Eyes(runner)

Configuration config = eyes.getConfiguration()

config.setApiKey('')
config.addBrowser(900, 600, BrowserType.CHROME)
config.addBrowser(1200, 800, BrowserType.SAFARI)
config.setLayoutBreakpoints(true)
config.addBrowser(new IosDeviceInfo(IosDeviceName.iPhone_11))
config.addDeviceEmulation(DeviceName.Galaxy_S20, ScreenOrientation.PORTRAIT)

eyes.setConfiguration(config)

eyes.setMatchLevel(MatchLevel.STRICT)

eyes.setStitchMode(StitchMode.CSS)

eyes.setHideScrollbars(false)

eyes.setForceFullPageScreenshot(true //For full page screenshot
    )


if (true) {
    BatchInfo batchInfo = new BatchInfo('Guayabitas- Aviation validation')

    batchInfo.setId('GPORTAL-1706' // passing the TestId so all tests will be grouped together in applitools
        )

    eyes.setBatch(batchInfo)
}

'Open Eyes'
eyes.open(innerDriver, 'DemoApp', 'DemoTest' // ,viewportSize)
    )

WebUI.navigateToUrl('https://demo.applitools.com')

counter = 0

eyes.check('demo page', Target.window().fully())

/*
//eyes.check('http://test-land.wfscorp.com/', Target.window().fully())
for (String aURL : allURLs) {
    if (aURL.startsWith('https://test-aviation.wfscorp.com') && !(aURL.endsWith('.png')) && !(aURL.endsWith('.svg')) && !(aURL.contains('.jpg')) && 
    !(aURL.endsWith('.js')) && !(aURL.endsWith('.css'))) {
        counter = (counter + 1)
        WebUI.navigateToUrl(aURL)
        WebUI.delay(3)
        eyes.check(aURL, Target.window().fully())
    }
	if (counter == 6){
		break
	}
}
*/
eyes.close()

println('Number of pages tested =' + counter)

WebUI.closeBrowser()

