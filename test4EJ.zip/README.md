# Applitools Tutorial - Images Java

Get started with Applitools Eyes visual testing with this basic example of using the Java and the Eyes Images SDK.

Learn more about how to install and start this project with our [Images Java tutorial](https://applitools.com/tutorials/screenshots-java.html)!

<https://applitools.com/tutorials/screenshots-java.html>

## More Information

Learn more about Applitools [Eyes](https://info.applitools.com/ucY77) and the [Ultrafast Test Cloud](https://info.applitools.com/ucY78) at [applitools.com](https://info.applitools.com/ucY76).

More about the Images Java SDK:
- https://applitools.com/docs/api/eyes-sdk/index-gen/class-eyes-images-java.html
