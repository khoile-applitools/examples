package com.applitools.app;

import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.TestResultsSummary;
import com.applitools.eyes.config.Configuration;
import com.applitools.eyes.images.Eyes;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.images.ImageRunner;
import com.applitools.eyes.images.Target;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import java.net.URL;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.nio.file.Paths;


import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import java.io.File;


public class DemoTest {
    private static EyesRunner runner = new ImageRunner();
    private static Configuration config = new Configuration();

    @BeforeAll
    public static void setUp(){        
        //config.setServerUrl("https://eyes.applitools.com/"); //set by default
        // Define the OS and hosting application to identify the baseline.
        config.setHostOS("Windows 11");
        config.setHostApp("My App");


    }

    @Test
    public void test() {
        
        Eyes eyes = new Eyes(runner);
        
        config = eyes.getConfiguration();
        config.setApiKey("");
        
        eyes.setConfiguration(config);

        try {
            // Start the test with a viewport size of 800x600.
            //eyes.open("Demo App - PDF Java", "Smoke Test - PDF Java");
            eyes.open("Demo App - PDF Java", "Smoke Test 2 - PDF Java", new RectangleSize(800, 600));
            
            PDDocument document = PDDocument.load(new File("Test2.pdf"));

            // Create a PDFRenderer object
            PDFRenderer pdfRenderer = new PDFRenderer(document);

            // Iterate through each page and convert it to an image
            for (int pageIndex = 0; pageIndex < document.getNumberOfPages(); pageIndex++) {
                BufferedImage image = pdfRenderer.renderImage(pageIndex);
                
                // Now you can use the 'image' as needed
                // For example, you can save it to a file or perform further processing
                
                // Visual validation.
                eyes.check("Image buffer", Target.image(image));
            }

            // Close the PDF document
            document.close();

           

          

            // End visual UI testing.
            eyes.closeAsync();
        } catch(IOException ex){
            System.out.println(ex);
        } finally {
            // If the test was aborted before eyes.close was called, ends the test as aborted.
            eyes.abortIfNotClosed();
        }
    }

    @AfterAll
    public static void tearDown(){
        //wait for Applitools test to finish and fetch the results
        TestResultsSummary  results = runner.getAllTestResults();
        System.out.println(results);
    }
}
