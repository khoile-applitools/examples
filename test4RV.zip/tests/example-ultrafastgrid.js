'use strict';
const fs = require('fs');
const csv = require('csv-parser');
const moment = require('moment');
const axios = require('axios');

const {
  VisualGridRunner,
  RunnerOptions,
  Eyes,
  Target,
  Configuration,
  BatchInfo,
  BrowserType,
  DeviceName,
  ScreenOrientation,
  ConsoleLogHandler,
  iosDeviceInfo,
  IosDeviceName,
  IosVersion,
  ClassicRunner
} = require('@applitools/eyes-webdriverio');
const { DriverConfig } = require('appium/build/lib/extension/driver-config');
const { FileLogHandler } = require('@applitools/eyes-selenium');
const { StitchMode } = require('@applitools/eyes-images');

let eyes;
let runner;
let configuration;

const header = ['App Name', 'Test Name', 'Device', 'Step Name', 'Unresolved', 'Passed', 'Date'];
const header2 = ['App Name', 'Test Name', 'Step Name', 'Unresolved', 'Passed', 'Date'];

describe('ACME Demo App - wdio6', function () {

  before(async () => {
    // Create a runner with concurrency of 5
    // You can increase this value if your plan supports a higher concurrency

    const runnerOptions = new RunnerOptions().testConcurrency(5);

    runner = new VisualGridRunner(runnerOptions);
    //runner = new ClassicRunner();

    // Create Eyes object with the runner, meaning it'll be a Visual Grid eyes.

    eyes = new Eyes(runner);
    
    //eyes.addProperty("Test_Env", "test");

    //if (browser.config.enableEyesLogs) {
      eyes.setLogHandler(new FileLogHandler(true, "test.log", false));
    //}

    // Initialize the eyes configuration

    configuration = eyes.getConfiguration();

    // use new Configuration() when not setting eyes setter methods. e.g. eyes.setLogHandler() etc...
    // new Configuration();

    // You can get your api key from the Applitools dashboard

    configuration.setApiKey(process.env.APPLITOOLS_API_KEY);

    // configuration.setUseDom(true);
     configuration.setStitchMode(StitchMode.CSS);

     

    //configuration.setHideCaret(false);

    // create a new batch info instance and set it to the configuration
    configuration.setLayoutBreakpoints(true);

    configuration.setBatch(new BatchInfo('Demo Batch - WDIO 6 - Ultrafast'))


    //configuration.addBrowser(1920, 1080, BrowserType.CHROME);
    //configuration.addBrowser(1920, 1080, BrowserType.SAFARI);
   // configuration.addBrowser(800, 600, BrowserType.CHROME);
    //configuration.addBrowser(700, 500, BrowserType.FIREFOX);
    //configuration.addBrowser(1600, 1200, BrowserType.IE_11);
    
    
    
    configuration.addBrowser(1024, 768, BrowserType.EDGE_CHROMIUM);
    configuration.addBrowser(1200, 953, BrowserType.SAFARI);
    

  //  configuration.setUseDom(true);
/*
    configuration.addBrowser({iosDeviceInfo: {
      deviceName: IosDeviceName.iPhone_11,
      screenOrientation: ScreenOrientation.PORTRAIT, // optional, default: ScreenOrientation.PORTRAIT
      iosVersion: IosVersion.LATEST // optional, default: undefined (i.e. the default is determined by the Ultrafast grid)
    },
    });

    configuration.addBrowser({iosDeviceInfo: {
      deviceName: IosDeviceName.iPhone_14,
      screenOrientation: ScreenOrientation.PORTRAIT, // optional, default: ScreenOrientation.PORTRAIT
      iosVersion: IosVersion.LATEST // optional, default: undefined (i.e. the default is determined by the Ultrafast grid)
    },
    });

    configuration.addBrowser({iosDeviceInfo: {
      deviceName: IosDeviceName.iPad_Pro_12_9_inch_6,
      screenOrientation: ScreenOrientation.PORTRAIT, // optional, default: ScreenOrientation.PORTRAIT
      iosVersion: IosVersion.LATEST // optional, default: undefined (i.e. the default is determined by the Ultrafast grid)
    },
    });

    // Add mobile emulation devices in Portrait mode
   // configuration.addDeviceEmulation(DeviceName.Galaxy_S10, ScreenOrientation.PORTRAIT);
    configuration.addDeviceEmulation(DeviceName.iPhone_X, ScreenOrientation.PORTRAIT);
    configuration.addDeviceEmulation(DeviceName.Pixel_2, ScreenOrientation.PORTRAIT);
    configuration.addDeviceEmulation(DeviceName.Pixel_2, ScreenOrientation.PORTRAIT);


    */
  });


  beforeEach(async function () {

    
    configuration.setAppName('Demo App - WDIO 6 - Ultrafast');
    configuration.setTestName('Smoke Test - WDIO 6 - Ultrafast');
    await eyes.open(driver);
  });


  it('ultraFastTest', async () => {

   
    await driver.url('https://card.americanexpress.com/m/delta/?jo_&dynamic_disabled&callcenter=closed&disableOffers=true&acceptModal=false&exp=0');

    await driver.pause(2000);
  
    const matchResult = await eyes.check('Login Window', Target.window().fully().lazyLoad(true,500));
    
    await eyes.close();
  });

  afterEach(async () => {
    console.log("aborting non closed");
    // If the test was aborted before eyes.close was called, ends the test as aborted.
    //await eyes.abortAsync();
  });



  after(async () => {
    console.log("getting results");
    const summary = await runner.getAllTestResults(false);


    console.log(summary);


  });
});
